// Простой сервер на Node.js
const express = require('express');
const app = express();
require('dotenv').config();
app.use(express.static('public'));

app.listen(3000, () => {
  console.log('Сервер запущен на порту 3000');
});